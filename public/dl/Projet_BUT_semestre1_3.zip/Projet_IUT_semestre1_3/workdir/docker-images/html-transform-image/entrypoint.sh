#!/bin/bash

wd=$(pwd)

mkdir temp/html
chmod 777 temp/html

for folder in $wd/temp/textes_converted/*; do
    ../script.php $(basename "$folder")
done

tar -czf out/html.tar.gz temp/html

/bin/bash