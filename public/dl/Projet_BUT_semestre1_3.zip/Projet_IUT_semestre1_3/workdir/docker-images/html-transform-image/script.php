#!/usr/bin/php
<?php
    if(sizeof($argv) == 2){
        $code_region = $argv[1];
        date_default_timezone_set('Europe/Paris');

        echo "Traitement de la région : $code_region...\n";

        $html = file_get_contents("in/template/pdf.html");
        $regions = file_get_contents("in/regions.conf");

        $comm = json_decode(file_get_contents("temp/textes_converted/$code_region/comm.dat"), true);
        $tableau = json_decode(file_get_contents("temp/textes_converted/$code_region/tableau.dat"), true);
        $texte = json_decode(file_get_contents("temp/textes_converted/$code_region/texte.dat"), true);

        $nom = shell_exec('echo "'.$regions.'" | egrep "'.$code_region.'" | cut -d \',\' -f 2');
        $population = preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', shell_exec('echo "'.$regions.'" | egrep "'.$code_region.'" | cut -d \',\' -f 3'));
        $superficie = preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', shell_exec('echo "'.$regions.'" | egrep "'.$code_region.'" | cut -d \',\' -f 4'));
        $nb_departements = preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', shell_exec('echo "'.$regions.'" | egrep "'.$code_region.'" | cut -d \',\' -f 5'));
        $image_couverture = "../../in/logos/$code_region.png";
        $jour = date("d");
        $mois = date("m");
        $annee = date("Y");
        $heure = date("H");
        $minute = date("i");
        $trimestre = "0".ceil(date('n') / 3);

        /*Texte*/
        $texte_temp = [];
        $texte_client = "";

        foreach(array_keys($texte["titres"]) as $key => $value){
            $texte_temp[$value] = $texte["titres"][$value];
        }
        foreach(array_keys($texte["sous_titres"]) as $key => $value){
            $texte_temp[$value] = $texte["sous_titres"][$value];
        }
        foreach(array_keys($texte["textes"]) as $key => $value){
            $texte_temp[$value] = $texte["textes"][$value];
        }
        ksort($texte_temp);
        foreach($texte_temp as $key => $value){
            $texte_client .= $value;
        }
        /*Fin Texte*/

        /*Tableau*/
        $tableau_produits = "";

        foreach($tableau["stats"] as $key => $value){
            $tableau_produits .= "<tr>";
            $tableau_produits .= "<td>".$value["product_number"]."</td>";
            $tableau_produits .= "<td>".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["ventes_trimestre"])."</td>";
            $tableau_produits .= "<td>".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["ca_trimestre"])."</td>";
            $tableau_produits .= "<td>".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["ventes_trimestre_precedent"])."</td>";
            $tableau_produits .= "<td>".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["ca_trimestre_precedent"])."</td>";
            if(number_format($value["evolution_ca_pourcentage"], 2) >= 0){
                $couleur = "#71ad47";
            }else{
                $couleur = "#ff3e45";
            }
            $tableau_produits .= "<td style=\"background-color: $couleur;\">".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["evolution_ca_pourcentage"])."</td>";
            if(number_format($value["evolution_ca_va"], 2) >= 0){
                $couleur = "#71ad47";
            }else{
                $couleur = "#ff3e45";
            }
            $tableau_produits .= "<td style=\"background-color: $couleur;\">".preg_replace('/(?<=\d)(?=(\d{3})+(?!\d))/', ' ', $value["evolution_ca_va"])."</td>";
            $tableau_produits .= "</tr>";
        }
        /*Fin Tableau*/

        /*Commerciales*/
        $image_commercial_1 = "../photos_converted/".$comm['meilleurs'][0]['nickname'].".png";
        $image_commercial_2 = "../photos_converted/".$comm['meilleurs'][1]['nickname'].".png";
        $image_commercial_3 = "../photos_converted/".$comm['meilleurs'][2]['nickname'].".png";

        $nom_commercial_1 = $comm['meilleurs'][0]['firstname']." ".uppercase($comm['meilleurs'][0]['lastname']);
        $nom_commercial_2 = $comm['meilleurs'][1]['firstname']." ".uppercase($comm['meilleurs'][1]['lastname']);
        $nom_commercial_3 = $comm['meilleurs'][2]['firstname']." ".uppercase($comm['meilleurs'][2]['lastname']);

        $ca_commercial_1 = $comm['meilleurs'][0]['ca'];
        $ca_commercial_2 = $comm['meilleurs'][1]['ca'];
        $ca_commercial_3 = $comm['meilleurs'][2]['ca'];
        /*Fin commerciales*/

        $lien = "https://bigbrain.biz/".$code_region;
        $qrcode = "../qrcodes/".$code_region.".png";
        $credits = $texte["credits"];

        /*Remplacements*/
        $html = str_replace("%REGION%", trim($nom), $html);
        $html = str_replace("%NB_HABITANT%", trim($population), $html);
        $html = str_replace("%SUPERFICIE%", trim($superficie), $html);
        $html = str_replace("%NB_DEPARTEMENTS%", trim($nb_departements), $html);
        $html = str_replace("%IMAGE_COUVERTURE%", $image_couverture, $html);
        $html = str_replace("%JOUR%", $jour, $html);
        $html = str_replace("%MOIS%", $mois, $html);
        $html = str_replace("%ANNEE%", $annee, $html);
        $html = str_replace("%HEURE%", $heure, $html);
        $html = str_replace("%MINUTE%", $minute, $html);
        $html = str_replace("%TRIMESTRE%", $trimestre, $html);
        $html = str_replace("%TEXTE_CLIENT%", $texte_client, $html);
        $html = str_replace("%TABLEAU%", $tableau_produits, $html);
        $html = str_replace("%IMG_COMMERCIAL_1%", $image_commercial_1, $html);
        $html = str_replace("%IMG_COMMERCIAL_2%", $image_commercial_2, $html);
        $html = str_replace("%IMG_COMMERCIAL_3%", $image_commercial_3, $html);
        $html = str_replace("%NOM_COMMERCIAL_1%", $nom_commercial_1, $html);
        $html = str_replace("%NOM_COMMERCIAL_2%", $nom_commercial_2, $html);
        $html = str_replace("%NOM_COMMERCIAL_3%", $nom_commercial_3, $html);
        $html = str_replace("%CA_1%", $ca_commercial_1, $html);
        $html = str_replace("%CA_2%", $ca_commercial_2, $html);
        $html = str_replace("%CA_3%", $ca_commercial_3, $html);
        $html = str_replace("%LIEN%", $lien, $html);
        $html = str_replace("%QRCODE%", $qrcode, $html);
        $html = str_replace("%CREDITS%", $credits, $html);
        /*Fin Remplacements*/

        file_put_contents("/distant/temp/html/".$code_region.".html", $html);
    }else{
        echo "Usage : ./script.php <code_region>\n";
    }

    function uppercase($string) {
        $string = strtoupper($string);
        return $string;
    }
?>