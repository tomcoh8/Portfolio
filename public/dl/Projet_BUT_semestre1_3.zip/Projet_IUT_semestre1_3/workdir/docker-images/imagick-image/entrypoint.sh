#!/bin/bash

mkdir temp/photos_converted
chmod 777 temp/photos_converted

width=200
height=200

wd=$("pwd")

for file in $wd/in/photos/*.svg
do
    svg=$(basename "$file")
    svg=$(echo "$svg" | tr '[:upper:]' '[:lower:]')
    png="${svg%.*}.png"

    svg="$wd/in/photos/$svg"
    png="$wd/temp/photos_converted/$png"

    echo "Conversion de $file en $width x $height..."
	rsvg-convert -w "$width" -h "$height" "$svg" -o "$png"
    echo "Conversion de $file nuance de gris..."
    convert -type Grayscale "$png" "$png"
    echo "Conversion de $file terminée"
done

tar -czf out/photos_converted.tar.gz temp/photos_converted

/bin/bash