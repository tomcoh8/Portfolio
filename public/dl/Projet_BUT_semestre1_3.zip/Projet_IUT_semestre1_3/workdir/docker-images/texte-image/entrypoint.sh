#!/bin/bash

mkdir temp/textes_converted
chmod 777 temp/textes_converted

wd=$(pwd)

for file in $wd/in/textes/*.txt; do
    echo $file
    ../script.php "$file"
done

tar -czf out/textes_converted.tar.gz temp/textes_converted

/bin/bash