#!/usr/bin/php
<?php
/*
    Ce progragramme récupère un fichier texte et génère les fichiers texte.dat, tableau.dat et comm.dat
    Le format du fichier d'output est du JSON
    Principe de fonctionnement :
    On récupère les lignes du fichier texte
    On supprime les lignes vides
    On supprime les accents
    On met en minuscule

    Pour les textes avec des bornes, on récupère la ligne du début de la zone et la ligne de fin de la zone
    On récupère ensuite les lignes entre ces deux bornes, par rapport au fichier original
    
    Pour les lignes avec des : ou =, on récupère le numéro de ligne, puis on récupère le contenu dans le fichier original

    On vérifie s'il y a des liens dans les textes, et on les transforme en anchor HTML

    On génère les fichiers texte.dat, tableau.dat et comm.dat
*/
    if(sizeof($argv) == 2){
        $file_name = $argv[1];
        echo "Traitement du fichier $file_name...\n";
        if(file_exists($file_name)){
            $file_content_original = trim_lines(file_get_contents($file_name));
            $file_content_original_parsed = restartIndex(explode("\n", $file_content_original));
            $file_content_modified = lowercase(remove_accents($file_content_original));
            
            $regex_element = "^[[:space:]]*[0-9]+[[:space:]]+<ELEMENT>[[:space:]]*(=|:)";
            $regex_areas = "^[[:space:]]*[0-9]+[[:space:]]+<ELEMENT>$";
            
            generateJSON($file_content_original_parsed, $file_content_modified, $regex_element, $regex_areas);
            echo "Fichier : ".$file_name." traité avec succès\n";
        }else{
            echo "Fichier : ".$file_name." non trouvé\n";
        }
    }else{
        echo "Usage : ./script.php <fichier>\n";
    }

    //Fonction principale appellante
    function generateJSON($file_content_original_parsed, $file_content_modified, $regex_element, $regex_areas){
        $texte = [];
        $tableau = [];
        $comm = [];
    
        $elements = getElements($file_content_original_parsed, $file_content_modified, $regex_element);
        $areas = getAreas($file_content_original_parsed, $file_content_modified, $regex_areas);
    
        $texte["code"] = $elements["code"];
        $texte["titres"] = generateLinks($elements["titre"]);
        $texte["sous_titres"] = generateLinks($elements["sous_titre"]);
        $texte["textes"] = generateLinks($areas["texte"]);
        $texte["credits"] = $areas["credits"];
    
        $tableau["code"] = $elements["code"];
        $tableau["stats"] = $areas["stats"];
    
        $comm["code"] = $elements["code"];
        $comm["meilleurs"] = $elements["meilleurs"];
    
        $texte_json = json_encode($texte, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        $tableau_json = json_encode($tableau, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        $comm_json = json_encode($comm, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    
        mkdir("temp/textes_converted/".$texte["code"]);
    
        file_put_contents("temp/textes_converted/".$texte["code"]."/texte.dat", $texte_json);
        file_put_contents("temp/textes_converted/".$texte["code"]."/tableau.dat", $tableau_json);
        file_put_contents("temp/textes_converted/".$texte["code"]."/comm.dat", $comm_json);

        shell_exec("chmod -R 777 temp/textes_converted/".$texte["code"]);
    }

    function generateLinks($array){
        if(count($array) != 0){
            $keys = array_keys($array);
        
            for ($i = 0; $i < count($keys); $i++) {
                $key = $keys[$i];
                $array[$key] = addLinks($array[$key]);
            }
        }

        return $array;
    }

    function addLinks($string){
        $match = shell_exec('echo "'.$string.'" | grep -oP "\[[^[]*?\][[:space:]]*\((https|http):\/\/.*?\)($|[[:space:]]+)"');
    
        if($match != ""){
            $match = restartIndex(explode("\n", $match));
            for ($i = 0; $i < count($match); $i++) {
                $element = trim($match[$i]);
            
                $nom = trim(shell_exec('echo "'.$element.'" | egrep -o "^\[.*?\]"'));
                $nom = substr($nom, 1, strlen($nom) - 2);
            
                $url = trim(shell_exec('echo "'.$element.'" | egrep -o "\(.*?\)$"'));
                $url = substr($url, 1, strlen($url) - 2);
            
                $string = str_replace($element, '<a href="'.$url.'">'.$nom.'</a>', $string);
            }
        }
    
        return $string;
    }

    function getAreas($file_content_original_parsed, $file_content_modified, $regex_areas){
        $debut_texte = array_keys(regexMatch($file_content_modified, $regex_areas, "debut_texte"));
        $fin_texte = array_keys(regexMatch($file_content_modified, $regex_areas, "fin_texte"));
    
        $debut_stats = array_keys(regexMatch($file_content_modified, $regex_areas, "debut_stats"));
        $fin_stats = array_keys(regexMatch($file_content_modified, $regex_areas, "fin_stats"));
    
        $debut_credits = array_keys(regexMatch($file_content_modified, $regex_areas, "debut_credits"));
        $fin_credits = array_keys(regexMatch($file_content_modified, $regex_areas, "fin_credits"));
    
        if(count($debut_texte) != count($fin_texte) || count($debut_stats) != count($fin_stats) || count($debut_credits) != count($fin_credits)) {
            echo "ERREUR: Une erreur est survenue lors de la récupération des zones de texte";
            exit;
        }else{
            $texte = getAreaContent($file_content_original_parsed, $debut_texte, $fin_texte);
            $stats = restartIndex(getAreaContent($file_content_original_parsed, $debut_stats, $fin_stats))[0];
            $credits = restartIndex(getAreaContent($file_content_original_parsed, $debut_credits, $fin_credits))[0];

            foreach(array_keys($texte) as $key => $value){
                $texte[$value] = addPAnchor($texte[$value]);
            }

            $stats_final = [];
            for ($i = 0; $i < count($stats); $i++) {
                $temp = str_replace(",", " ", $stats[$i]);
            
                $product_number = trim(shell_exec('echo "'.$temp.'" | egrep -oi "^prod[[:space:]]*#[0-9]+"'));
                $temp = trim(str_replace($product_number, "", $temp));
            
                $product_number = intval(trim(shell_exec('echo "'.$product_number.'" | egrep -o "[0-9]+$"')));
            
                $temp = explode(" ", $temp);
                $ventes_trimestre = intval($temp[0]);
                $ca_trimestre = intval($temp[1]);
                $ventes_trimestre_precedent = intval($temp[2]);
                $ca_trimestre_precedent = intval($temp[3]);
                $evolution_ca_pourcentage = round(($ca_trimestre - $ca_trimestre_precedent) / $ca_trimestre_precedent * 100, 2);
                $evolution_ca_va = $ca_trimestre - $ca_trimestre_precedent;
            
                $stats_final[] = array(
                    "product_number" => $product_number,
                    "ventes_trimestre" => $ventes_trimestre,
                    "ca_trimestre" => $ca_trimestre,
                    "ventes_trimestre_precedent" => $ventes_trimestre_precedent,
                    "ca_trimestre_precedent" => $ca_trimestre_precedent,
                    "evolution_ca_pourcentage" => $evolution_ca_pourcentage,
                    "evolution_ca_va" => $evolution_ca_va
                );
            }
        
            usort($stats_final, function($a, $b) {
                return $a['product_number'] - $b['product_number'];
            });
        
            for ($i = 0; $i < count($credits); $i++) {
                $temp = trim(shell_exec('echo "'.$credits[$i].'" | egrep -oi "^-[[:space:]]*"'));
                $credits[$i] = trim(str_replace($temp, "", $credits[$i]));
            }

            $credits_str = "";
            for ($i = 0; $i < count($credits); $i++) {
                $credits_str .= "<li>".addLinks($credits[$i])."</li>";
            }
        
            return array("texte" => $texte, "stats" => $stats_final, "credits" => $credits_str);
        }
    }

    function addPAnchor($array){
        $paragraph = "";

        for ($i = 0; $i < count($array); $i++) {
            $paragraph .= "<p>".$array[$i]."</p>";
        }
    
        return $paragraph;
    }

    function getAreaContent($file_content_original_parsed, $ligne_debut, $ligne_fin){
        $res = [];
    
        for ($i = 0; $i < count($ligne_debut); $i++) {
            $debut = $ligne_debut[$i];
            $fin = $ligne_fin[$i];
        
            $lignes = [];
        
            for ($j = $debut; $j < $fin-1; $j++) {
                $lignes[] = $file_content_original_parsed[$j];
            }
        
            $res[$debut] = $lignes;
        }
    
        return $res;
    }

    function getElements($file_content_original, $file_content_modified, $regex_element){
        $code = array_keys(regexMatch($file_content_modified, $regex_element, "code"));
        $titre = array_keys(regexMatch($file_content_modified, $regex_element, "titre"));
        $sous_titre = array_keys(regexMatch($file_content_modified, $regex_element, "sous_titre"));
        $meilleurs = array_keys(regexMatch($file_content_modified, $regex_element, "meilleurs"));
    
        $code = uppercase(restartIndex(getElementContent($file_content_original, $code, "code"))[0]);
        $titre = getElementContent($file_content_original, $titre, "titre");
        $sous_titre = getElementContent($file_content_original, $sous_titre, "sous_titre");
        $meilleurs = restartIndex(getElementContent($file_content_original, $meilleurs, "meilleurs"))[0];

        foreach(array_keys($titre) as $key => $value){
            $titre[$value] = "<h1>".$titre[$value]."</h1>";
        }

        foreach(array_keys($sous_titre) as $key => $value){
            $sous_titre[$value] = "<h2>".$sous_titre[$value]."</h2>";
        }
        
        $meilleurs_temp = explode(",", $meilleurs);
        for ($i = 0; $i < count($meilleurs_temp); $i++) {
            $meilleurs_temp[$i] = trim($meilleurs_temp[$i]);
        
            $res = shell_exec('echo "'.$meilleurs_temp[$i].'" | egrep -o "^[a-zA-Z]{3}/"');
        
            if($res != ""){
                $nickname = trim($res);
                $meilleurs_temp[$i] = trim(str_replace($nickname, "", $meilleurs_temp[$i]));
            
                $nickname = lowercase(explode("/", $nickname)[0]);
            }else{
                $nickname = "";
            }
        
            $ca = trim(shell_exec('echo "'.$meilleurs_temp[$i].'" | egrep -o "=.*€$"'));
            $meilleurs_temp[$i] = trim(str_replace($ca, "", $meilleurs_temp[$i]));
        
            $ca = intval(str_replace("K€", "", str_replace("=", "", uppercase($ca))));
        
            $firstname = trim(shell_exec('echo "'.$meilleurs_temp[$i].'" | egrep -o "^[a-zA-Z]*[[:space:]]"'));
            $meilleurs_temp[$i] = trim(str_replace($firstname, "", $meilleurs_temp[$i]));
        
            $lastname = trim($meilleurs_temp[$i]);
        
            $meilleurs_temp[$i] = array("nickname" => $nickname, "firstname" => $firstname, "lastname" => $lastname, "ca" => $ca);
        }
    
        usort($meilleurs_temp, function($a, $b) {
            return $b['ca'] - $a['ca'];
        });
    
        return array("code" => $code, "titre" => $titre, "sous_titre" => $sous_titre, "meilleurs" => $meilleurs_temp);
    }

    function getElementContent($file_content_original_parsed, $element, $type){
        $res = [];
    
        for ($i = 0; $i < count($element); $i++) {
            $ligne = $element[$i];
            $res[$ligne] = $file_content_original_parsed[$ligne-1];
            $match = trim(shell_exec('echo "'.$res[$ligne].'" | egrep -oi "^'.$type.'[[:space:]]*(=|:)"'));
            $res[$ligne] = trim(str_replace($match, "", $res[$ligne]));
        }
    
        return $res;
    }

    function trim_lines($string) {
        $lines = explode("\n", $string);
        $res = "";
    
        for ($i = 0; $i < count($lines); $i++) {
            $line = $lines[$i];
            $res .= trim($line)."\n";
        }
    
        return $res;
    }

    function regexMatch($string, $regex, $type) {
        $regex = str_replace("<ELEMENT>", $type, $regex);
        $code = shell_exec('echo "'.$string.'" | egrep "'.$regex.'"');
        if(strlen($code || "") == 0) return [];
    
        $lines = explode("\n", trim($code));
    
        $res = [];
    
        for ($i = 0; $i < count($lines); $i++) {
            $line = $lines[$i];
        
            $match = trim(shell_exec('echo "'.$line.'" | egrep -o "^[[:space:]]*[0-9]*[[:space:]]*"'));
        
            $key = intval($match);
            $value = trim(str_replace($match, "", $line));
        
            $res[$key] = $value;
        }
    
        return $res;
    }

    function restartIndex($array){
        return array_values(array_filter($array, function($value) { return $value !== ''; }));
    }

    function remove_accents($string) {
        $string = shell_exec('echo "'.$string.'" | sed "s/[àáâãäå]/a/g;s/[ç]/c/g;s/[èéêë]/e/g;s/[ìíîï]/i/g;s/[ñ]/n/g;s/[òóôõöø]/o/g;s/[ùúûü]/u/g;s/[ýÿ]/y/g;s/[ß]/ss/g;s/[ÀÁÂÃÄÅ]/A/g;s/[Ç]/C/g;s/[ÈÉÊË]/E/g;s/[ÌÍÎÏ]/I/g;s/[Ñ]/N/g;s/[ÒÓÔÕÖØ]/O/g;s/[ÙÚÛÜ]/U/g;s/[Ý]/Y/g;" | nl -w2 -s" "');
        return $string;
    }

    function uppercase($string) {
        $string = strtoupper($string);
        return $string;
    }

    function lowercase($string) {
        $string = strtolower($string);
        return $string;
    }
?>