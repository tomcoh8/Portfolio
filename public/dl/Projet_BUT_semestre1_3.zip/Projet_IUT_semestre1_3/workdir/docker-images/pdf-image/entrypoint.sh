#!/bin/bash

wd=$(pwd)

mkdir temp/pdf
chmod 777 temp/pdf

for file in $wd/temp/html/*; do
    code_region=$(basename $file .html)
    nom_region=$(cat in/regions.conf | grep $code_region | cut -d',' -f2)
    nom_region=$(echo $nom_region | tr ',' '-' | tr ' ' '-')
    out="$code_region-$nom_region.pdf"
    html2pdf "temp/html/$code_region.html" "temp/pdf/$out"
done

tar -czf pdf.tar.gz -C temp pdf

/bin/bash