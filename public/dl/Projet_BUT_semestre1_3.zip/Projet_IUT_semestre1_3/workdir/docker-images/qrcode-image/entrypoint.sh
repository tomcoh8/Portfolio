#!/bin/bash

FILE=in/regions.conf

if test -f "$FILE"; then
    mkdir temp/qrcodes
    chmod 777 temp/qrcodes

    while IFS="," read -r iso nom population superficie nb_departements
    do
        echo "Génération du QRCode pour $iso..."
        qrencode "https://bigbrain.biz/$iso" -o "temp/qrcodes/$iso.png"
        echo "QRCode : $iso généré avec succès"
    done < <(tail -n +2 $FILE)

    tar -czf out/qrcode.tar.gz temp/qrcodes
else
    echo "$FILE was not found in the current directory."
fi

/bin/bash