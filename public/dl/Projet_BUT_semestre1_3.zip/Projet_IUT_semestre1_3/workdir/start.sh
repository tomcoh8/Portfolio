function checkFiles() {
    echo "=== Checking files ==="

    wd=$(pwd)
    ok=1

    elements=(
        "docker-images/"
        "in/"
        "in/logos/"
        "in/photos/"
        "in/template/"
        "in/textes/"
        "in/regions.conf"
    )

    for i in "${elements[@]}"; do
        if [ ! -d "$wd/$i" ] && [ ! -f "$wd/$i" ];
        then
            echo "\"$i\" not found"
            ok=0
        fi
    done

    if [ $ok -eq 0 ];
    then
        echo "Please check your files before running the script"
        exit 1
    fi

    echo "Files and Folders OK"
}

function checkDockerInstalled() {
    echo "=== Checking if Docker is installed ==="

    if [ -z "$(command -v docker)" ];
    then
        echo "Docker is not installed"
        echo "Please install Docker before running the script"
        exit 1
    fi

    echo "Docker is Installed"
}

function checkDockerRunning() {
    echo "=== Checking if Docker is running ==="

    if ! curl -s --unix-socket /var/run/docker.sock http/_ping 2>&1 >/dev/null
    then
        echo "Docker is not running"
        echo "Please start Docker before running the script"
        exit 1
    fi

    echo "Docker is Running"
}

function removeDockerImages() {
    echo "=== Removing Docker images ==="

    images=($(ls docker-images/))

    for i in "${images[@]}"; do
        echo "Removing \"$i\""
        docker rmi $i > /dev/null 2>&1
    done

    echo ""
    echo "All Docker images removed"
}

function checkDockerImages() {
    echo "=== Checking if Docker images are installed ==="

    images=($(ls docker-images/))
    to_install=()
    ok=1

    for i in "${images[@]}"; do
        if [ -z "$(docker images -q $i)" ];
        then
            echo "Docker image \"$i\" is not installed"
            to_install+=("$i")
            ok=0
        fi
    done

    if [ $ok -eq 1 ];
    then
        echo "Docker images are installed"
    else
        echo ""
        echo "Docker image(s) to install: ${to_install[@]}"
    fi
}

function buildDockerImages() {
    if [ $# -eq 0 ];
    then
        return
    fi

    echo "=== Building and Installating Docker images ==="

    for i in "$@"; do
        echo "Building and Installing \"$i\""
        docker build -t $i docker-images/$i
    done

    echo ""
    echo "All Docker images installed"
}

function runImages(){
    echo "=== Running Docker images ==="

    if [ -d "out" ];
    then
        rm -Rf out
    fi

    if [ -d "temp" ];
    then
        rm -Rf temp
    fi

    mkdir out
    mkdir temp

    images=(
        "texte-image"
        "qrcode-image"
        "imagick-image"
        "html-transform-image"
        "pdf-image"
    )
    PWD=$(pwd)

    for i in "${images[@]}"; do
        echo "Running \"$i\""
        docker run --rm -v "$PWD":/distant $i > /dev/null 2>&1
    done

    rm -Rf temp

    echo ""
    echo "All Docker images ran"
}

checkFiles
checkDockerInstalled
checkDockerRunning
#removeDockerImages
checkDockerImages
buildDockerImages "${to_install[@]}"
runImages