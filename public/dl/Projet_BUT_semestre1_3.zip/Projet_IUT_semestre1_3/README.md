# Big Brain PDF Generator

## Pre-requisites :
- Docker installed
- curl installed (apt install curl | brew install curl)
- MacOS | Linux | Windows (WSL2)

## Reguired Files and Folders :
```
workdir
│─  start.sh
│
└───docker-images
│   │───html-transform-image
│   │   │─  *
│   │
│   └───imagick-image
│   │   │─  *
│   │
│   └───pdf-image
│   │   │─  *
│   │
│   └───qrcode-image
│   │   │─  *
│   │
│   └───texte-image
│   │   │─  *
│   
│  
└───in
    │─  regions.conf
    │
    │───logos
    │   │─  *.png
    │
    │───photos
    │   │─  *.svg
    │
    │───template
    │   │─  *
    │
    │───textes
    │   │─  *.txt
```

## Tested Platforms :
- Mac (M2 Chip) + Docker Desktop
- Windows 11 (WSL2) + Docker Desktop

## How to run / build :
- cd workdir
- chmod +x start.sh
- ./start.sh

## Output :
- tar.gz file containing PDFs will be generated in the workdir folder

## How to update files :
- You can only update / create / delete files that are in the childs folders of the "workdir/in" folder
- The only file you can update in "workdir/in" is regions.conf to add or remove regions

## Notes :
- We replaced "magick" which is used to convert SVG to PNG by "rsvg-convert" which don't have bugs with SVGs conversion (we still use magick to convert the PNG in shades of gray)
- We fixed the sae103-html2pdf Docker image that can't work on Mac M2 Chip