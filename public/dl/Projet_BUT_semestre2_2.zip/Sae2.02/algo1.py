from random import randint
from numpy import place
from sympy import false


def grille(n: int):
    return [[(i, j) for i in range(n)]for j in range(n)]


def affiche(tab: list):
    for i in range(len(tab)):
        print(tab[i])


def position(placement, grille, list_placement):
    list_res = []
    # test tous les coups possibles et les acjoutent dans une liste s'il ne dépassent pas du tableau
    if placement[0] - 1 >= 0 and placement[1] - 2 >= 0:
        list_res.append((placement[0] - 1, placement[1] - 2))
    if placement[0] + 1 <= len(grille)-1 and placement[1] - 2 >= 0:
        list_res.append((placement[0] + 1, placement[1] - 2))
    if placement[0] + 2 <= len(grille)-1 and placement[1] - 1 >= 0:
        list_res.append((placement[0] + 2, placement[1] - 1))
    if placement[0] + 2 <= len(grille)-1 and placement[1] + 1 <= len(grille)-1:
        list_res.append((placement[0] + 2, placement[1] + 1))
    if placement[0] + 1 <= len(grille)-1 and placement[1] + 2 <= len(grille)-1:
        list_res.append((placement[0] + 1, placement[1] + 2))
    if placement[0] - 1 >= 0 and placement[1] + 2 <= len(grille)-1:
        list_res.append((placement[0] - 1, placement[1] + 2))
    if placement[0] - 2 >= 0 and placement[1] + 1 <= len(grille)-1:
        list_res.append((placement[0] - 2, placement[1] + 1))
    if placement[0] - 2 >= 0 and placement[1] - 1 >= 0:
        list_res.append((placement[0] - 2, placement[1] - 1))

    # verifier si les coordonnées n'ont pas déjà été utilisées
    i = 0
    list_final = []

    for i in list_res :  # on se déplace dans les coups possible ajouté
       
        if i not in list_placement:
            list_final.append(i)

    return list_final


def cavalier(placement: tuple, list_placement, grille: list, impossible=[]):
    bloquer = false
    fini = false
    

    if list_placement == []:
        # si on à une liste de placement vide on ajoute sa position
        list_placement.append(placement)

    elif list_placement[-1] != placement:
        # on ajoute notre position dans la liste si on ne l'a pas deja fait auparavent (cas de retour en arrière)
        list_placement.append(placement)


    if len(grille[0])**2 - len(list_placement) == 0:
        # condition arret good

        return list_placement

    else:
        next_placement = position(placement, grille, list_placement)
        i = 0  # parcours des chemins possible du cavalier & non visiter

        

        print("placement impossible : ",impossible, "\n\n dernier coup joué :  \n", list_placement[-1], "\n")

        if next_placement == []:  # on est bloqué
            impossible.append(placement)
            print("bloqué  \n")

            list_placement = cavalier(list_placement[-2], list_placement[:-2], grille, impossible )
            #update de notre liste de placement

        # verifie tout les chemins donné par la fonction position
        while(i < len(next_placement) and not fini):

            if next_placement[i] not in impossible and next_placement[i] not in list_placement:
                print("prochain")
                
                # appel recursif qui test le prochain chemin
                impossible = []
                list_placement = cavalier(next_placement[i], list_placement, grille, impossible)

            if len(grille[0])**2 - len(list_placement) == 0:  # on a terminé le parcours
                fini = True

            i += 1
    
    
    return list_placement


n = int(input(print("taille plateau : ")))

tab = grille(n)

affiche(tab)
print("\n")

liste = cavalier((randint(0,n-1), randint(0,n-1)), [], tab) 


"""
liste = cavalier((0,7), [], tab )
"""
print(liste, len(liste)) 
