from random import randint


def grille(n: int):
    return [[(i, j) for i in range(n)]for j in range(n)]


def affiche(tab: list):
    for i in range(len(tab)):
        print(tab[i])


def position(placement, grille, list_placement,impossible):
    list_res = []
    # test tous les coups possibles et les acjoutent dans une liste s'il ne dépassent pas du tableau
    if placement[0] - 1 >= 0 and placement[1] - 2 >= 0:
        list_res.append((placement[0] - 1, placement[1] - 2))
    if placement[0] + 1 <= len(grille)-1 and placement[1] - 2 >= 0:
        list_res.append((placement[0] + 1, placement[1] - 2))
    if placement[0] + 2 <= len(grille)-1 and placement[1] - 1 >= 0:
        list_res.append((placement[0] + 2, placement[1] - 1))
    if placement[0] + 2 <= len(grille)-1 and placement[1] + 1 <= len(grille)-1:
        list_res.append((placement[0] + 2, placement[1] + 1))
    if placement[0] + 1 <= len(grille)-1 and placement[1] + 2 <= len(grille)-1:
        list_res.append((placement[0] + 1, placement[1] + 2))
    if placement[0] - 1 >= 0 and placement[1] + 2 <= len(grille)-1:
        list_res.append((placement[0] - 1, placement[1] + 2))
    if placement[0] - 2 >= 0 and placement[1] + 1 <= len(grille)-1:
        list_res.append((placement[0] - 2, placement[1] + 1))
    if placement[0] - 2 >= 0 and placement[1] - 1 >= 0:
        list_res.append((placement[0] - 2, placement[1] - 1))

    # verifier si les coordonnées n'ont pas déjà été utilisées
    i = 0
    list_final = []

    for i in list_res :  # on se déplace dans les coups possible ajouté
       
        if i not in list_placement and i not in impossible :
            list_final.append(i)

    return list_final


def avance(pos , grille, list_placement, impossible):
    possible = True
    if(position(pos, grille, list_placement,impossible) == [] ):
        possible = False

    return possible



def cavalier(placement: tuple, list_placement, grille: list, impossible):
    bloquer = False
    fini = False
    

    if list_placement == []:
        # si on à une liste de placement vide on ajoute sa position
        list_placement.append(placement)

    elif list_placement[-1] != placement:
        # on ajoute notre position dans la liste si on ne l'a pas deja fait auparavent (cas de retour en arrière)
        list_placement.append(placement)


    if len(grille[0])**2 - len(list_placement) == 0:
        # condition arret good
        return list_placement

    else: #cas ou pas de possibilité d'avancer
        next_placement = position(placement, grille, list_placement, impossible)
        
        if next_placement == []:  # on est bloqué
            impossible += [placement]
            list_placement = cavalier(list_placement[-2], list_placement[:-2], grille, impossible)
         
        # parcours des chemins possible du cavalier & non visiter
       
        for i in next_placement:
            possible = True

            if (avance(i , grille, list_placement, impossible)):#cas ou on peut avancer
                if len(list_placement) >= 58:
                    print("\n\n","pos : ",next_placement,"\n\n")
                    print("\n impossible : ", impossible)
                    return list_placement 

                list_placement = cavalier(i , list_placement, grille, [])
            else:
                impossible += [i]
                possible = False
                
        
        if not possible : # cas de retour en arrière
            print("backtrack")
            list_placement = cavalier(list_placement[-2], list_placement[:-2], grille,impossible)
    
    
    return list_placement


n = int(input(print("taille plateau : ")))

tab = grille(n)

affiche(tab)
print("\n")

#liste = cavalier((randint(0,n-1), randint(0,n-1)), [], tab, []) 



liste = cavalier((0,7), [], tab , [])

print(liste, len(liste)) 
