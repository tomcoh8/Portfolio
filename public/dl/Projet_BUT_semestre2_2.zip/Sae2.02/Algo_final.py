import tkinter as tk


# Constantes
MOUVEMENTS_CAVALIER_X = [2, 1, -1, -2, -2, -1, 1, 2]
MOUVEMENTS_CAVALIER_Y = [1, 2, 2, 1, -1, -2, -2, -1]
COULEUR_CASE_BLANCHE = "white"
COULEUR_CASE_GRIS = "gray"

def est_valide(x, y, plateau, taille_plateau):
    """
    Vérifie si un mouvement de cavalier est valide.
    """
    res = False
    if (x >= 0 and y >= 0 and x < taille_plateau and y < taille_plateau and plateau[x][y] == -1):
        res = True
    return res

def probleme_cavalier(debut, taille_plateau):
    """
    Résout le problème du cavalier pour un plateau d'échecs de taille taille_plateau x taille_plateau.
    """
    plateau = [[-1 for i in range(taille_plateau)] for j in range(taille_plateau)]
    if (est_valide(debut[0], debut[1], plateau, taille_plateau)): #vérifie les coordonnées de depart
        plateau[debut[0]][debut[1]] = 0
        etape = 1 
        res = [debut] 
        if (resoudre_probleme_cavalier(debut[0], debut[1], plateau, MOUVEMENTS_CAVALIER_X, MOUVEMENTS_CAVALIER_Y, etape, taille_plateau, res)):
            #affichage dans le terminal
            print("\n echiquier avec l'ordre de passage du cavalier \n")
            for i in range(len(plateau)):
                print(plateau[i])
            print("\n liste des coordonnées parcouru \n")
            print(res)

            # Création de la fenêtre Tkinter
            fenetre = tk.Tk()
            fenetre.title("Problème du cavalier")

            # Création du canevas pour afficher l'échiquier
            canvas_echiquier = tk.Canvas(fenetre, width=500, height=500)
            canvas_echiquier.pack(side=tk.LEFT, padx=10, pady=10)

            # Affichage de l'échiquier
            taille_case = 500 // taille_plateau
            for i in range(taille_plateau):
                for j in range(taille_plateau):
                    if (i + j) % 2 == 0:
                        canvas_echiquier.create_rectangle(j*taille_case, i*taille_case, (j+1)*taille_case, (i+1)*taille_case, fill=COULEUR_CASE_BLANCHE)
                    else:
                        canvas_echiquier.create_rectangle(j*taille_case, i*taille_case, (j+1)*taille_case, (i+1)*taille_case, fill=COULEUR_CASE_GRIS)
                    canvas_echiquier.create_text(j*taille_case+taille_case//2, i*taille_case+taille_case//2, text=str(plateau[i][j]))

            # Création de la listebox pour afficher la liste des coordonnées parcourues
            listebox_coordonnees = tk.Listbox(fenetre)
            listebox_coordonnees.pack(side=tk.LEFT, padx=10, pady=10)

            # Ajout des coordonnées dans la listebox
            for coordonnee in res:
                listebox_coordonnees.insert(tk.END, str(coordonnee))

            # Affichage de la fenêtre Tkinter
            fenetre.mainloop()

        else:
            print("Pas de solution")
    else :
        print("\n Attention les coordonnées de départ ne sont pas comprisent dans l'échiquier \n")


def resoudre_probleme_cavalier(x, y, plateau, x_mouvement, y_mouvement, etape, taille_plateau, res):
    """
    Fonction utilitaire récursive pour résoudre le problème du cavalier.
    """
    trouve_solution = False
    if (etape == taille_plateau * taille_plateau):
        return True
    for i in range(8):
        nouveau_x = x + x_mouvement[i]
        nouveau_y = y + y_mouvement[i]
        if (est_valide(nouveau_x, nouveau_y, plateau, taille_plateau)):
            plateau[nouveau_x][nouveau_y] = etape
            res.append((nouveau_x, nouveau_y))
            if (resoudre_probleme_cavalier(nouveau_x, nouveau_y, plateau, x_mouvement, y_mouvement, etape + 1, taille_plateau, res)):
                trouve_solution = True
            else : 
                plateau[nouveau_x][nouveau_y] = -1
                res.pop(-1)
    return trouve_solution


# Exemple d'utilisation: (couple de coordonnées + taille du plateau de jeu min 5)
probleme_cavalier((0,0), 8) 