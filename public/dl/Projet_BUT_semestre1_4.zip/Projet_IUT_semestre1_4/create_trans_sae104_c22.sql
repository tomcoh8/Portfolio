DROP SCHEMA IF EXISTS transmusicales CASCADE;
CREATE SCHEMA transmusicales;
SET SCHEMA 'transmusicales';


-- Creation de la classe _annee
CREATE TABLE _annee (
	an     INT     NOT NULL,
	CONSTRAINT _annee_pk PRIMARY KEY (an)
);
 
-- Creation de la classe _edition
CREATE TABLE _edition (
	nom_edition    	VARCHAR(50)     NOT NULL,
	an            	INT 	        NOT NULL,
	CONSTRAINT _edition_pk PRIMARY KEY (nom_edition),
	CONSTRAINT _edition_fk__annee FOREIGN KEY (an) REFERENCES _annee(an)
);
 
-- Creation de la classe _pays
CREATE TABLE _pays (
	nom_p     VARCHAR(20)     NOT NULL,
	CONSTRAINT _pays_pk PRIMARY KEY (nom_p)
);
 
-- Creation de la classe _ville
CREATE TABLE _ville (
	nom_v    	VARCHAR(20) 	NOT NULL,
	nom_p    	VARCHAR(20) 	NOT NULL,
	CONSTRAINT _ville_pk PRIMARY KEY (nom_v),
	CONSTRAINT _ville_fk__pays FOREIGN KEY (nom_p) REFERENCES _pays(nom_p)
);

-- Creation de la classe _lieu
CREATE TABLE _lieu (
	id_lieu    	VARCHAR(6)   	NOT NULL,
	nom_lieu   	VARCHAR(20) 	NOT NULL,
	accesPMR   	BOOL        	NOT NULL,
	capacite   	INT         	NOT NULL,
	type_lieu  	VARCHAR(20) 	NOT NULL,
	nom_v      	VARCHAR(20) 	NOT NULL,  
	CONSTRAINT _lieu_pk PRIMARY KEY (id_lieu),
	CONSTRAINT _lieu_fk__ville FOREIGN KEY (nom_v) REFERENCES _ville(nom_v)
);

-- Creation de la classe _groupe_artiste
CREATE TABLE  _groupe_artiste (
	id_Groupe_Artiste   	VARCHAR(6)	    NOT NULL,
	nom_groupe_artiste  	VARCHAR(30)     NOT NULL,
	site_web            	VARCHAR(50)     NOT NULL,
	an      			  	INT       	    NOT NULL,
	sortie_discographie     INT       	    NOT NULL,
	nom_p               	VARCHAR(20)     NOT NULL,
	CONSTRAINT _groupe_artiste_pk PRIMARY KEY (id_Groupe_Artiste),
	CONSTRAINT _groupe_artiste_fk__annee FOREIGN KEY (an) REFERENCES _annee(an), 
    CONSTRAINT _groupe_artiste_fk__annee FOREIGN KEY (sortie_discographie) REFERENCES _annee(an),
	CONSTRAINT _groupe_artiste_fk__pays FOREIGN KEY (nom_p) REFERENCES _pays(nom_p)
);
 
-- Creation de la classe _representation
CREATE TABLE _representation (
	numero_representation     VARCHAR(6)      NOT NULL,
	heure                 	  VARCHAR(20)     NOT NULL,
	date_representation   	  DATE        	  NOT NULL,
	id_lieu               	  VARCHAR(40) 	  NOT NULL,
	id_Groupe_Artiste     	  VARCHAR(40) 	  NOT NULL,
	CONSTRAINT _representation_pk PRIMARY KEY (numero_representation),
	CONSTRAINT _representation_fk__lieu FOREIGN KEY (id_lieu) REFERENCES _lieu(id_lieu),
	CONSTRAINT _representation_fk__groupe_artiste FOREIGN KEY (id_Groupe_Artiste) REFERENCES _groupe_artiste(id_Groupe_Artiste)
);

-- Creation de la classe _type_musique
CREATE TABLE _type_musique (
	type_m     VARCHAR(20)     NOT NULL,
	CONSTRAINT _type_musique_pk PRIMARY KEY (type_m)
 
);
 
-- Creation de la classe _concert
CREATE TABLE _concert (
	no_concert 	    VARCHAR(6)   	NOT NULL,
	titre       	VARCHAR(20)   	NOT NULL,
	resume       	VARCHAR(50)     NOT NULL,
	duree      	    INT	    		NOT NULL,
	tarif      	    FLOAT       	NOT NULL,
	type_m     	    VARCHAR(20)     NOT NULL,
	nom_edition     VARCHAR(20)     NOT NULL,
	CONSTRAINT _consert_pk PRIMARY KEY (no_concert),
	CONSTRAINT _consert_fk__lieu FOREIGN KEY (type_m) REFERENCES _type_musique(type_m),
	CONSTRAINT _consert_fk__edition FOREIGN KEY (nom_edition) REFERENCES _edition(nom_edition)
);
 
-- Creation de la classe _formation
CREATE TABLE _formation (
	libelle_formation     VARCHAR(30)     NOT NULL,
	CONSTRAINT _formation_pk PRIMARY KEY (libelle_formation)
);

-- Creation de l'association _a_pour
CREATE TABLE _a_pour (
	id_Groupe_Artiste_f     VARCHAR(6)      NOT NULL,
	libelle_formation_f 	VARCHAR(30)     NOT NULL,
	CONSTRAINT _a_pour_pk PRIMARY KEY (id_Groupe_Artiste_f, libelle_formation_f),
	CONSTRAINT _a_pour_fk__groupe_artiste FOREIGN KEY (id_Groupe_Artiste_f ) REFERENCES _groupe_artiste(id_Groupe_Artiste),
	CONSTRAINT _a_pour_fk__formation FOREIGN KEY (libelle_formation_f) REFERENCES _formation(libelle_formation)
);
 
-- Creation de l'association _type_ponctuel
CREATE TABLE _type_ponctuel (
	id_Groupe_Artiste_ponct     VARCHAR(6)       NOT NULL,
	type_m_ponct             	VARCHAR(30)      NOT NULL,
	type_ponctuel          	    VARCHAR(30)      NOT NULL,
	CONSTRAINT _type_ponctuel_pk PRIMARY KEY (id_Groupe_Artiste_ponct, type_m_ponct),
	CONSTRAINT _type_ponctuel_fk__groupe_artiste FOREIGN KEY (id_Groupe_Artiste_ponct) REFERENCES _groupe_artiste(id_Groupe_Artiste),
	CONSTRAINT _type_ponctuel_fk__type_musique FOREIGN KEY (type_m_ponct) REFERENCES _type_musique(type_m)
);
 
 
-- Creation de l'association _type_principal
CREATE TABLE _type_principal (
	id_Groupe_Artiste_princ     VARCHAR(6)      NOT NULL,
	type_m_princ            	VARCHAR(30)     NOT NULL,
	type_principal          	VARCHAR(30)     NOT NULL,
	CONSTRAINT _type_principal_pk PRIMARY KEY (id_Groupe_Artiste_princ, type_m_princ),
	CONSTRAINT _type_principal_fk__groupe_artiste FOREIGN KEY (id_Groupe_Artiste_princ ) REFERENCES _groupe_artiste(id_Groupe_Artiste),
	CONSTRAINT _type_principal_fk__type_musique FOREIGN KEY (type_m_princ) REFERENCES _type_musique(type_m)
); 



