#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define LIGNE 6
#define COLONNE 7

typedef int t_grille[LIGNE][COLONNE];

int main(int argc, char** argv);
void chargerGrille(char** argv, t_grille grille);
int min_max(t_grille grille, char pion, int profondeur);
int choix_colonne(t_grille grille, char pion);
bool jouerMinMax(t_grille grille, char pion, int colonne);
char inversePion(char pion);
void copieGrille(t_grille grille1, t_grille grille2);
char finMinMax(t_grille grille) ;

const int VIDE = 0;
const int JOUEUR = 1;
const int ADVERSAIRE = 2;

/*
* VOTRE STRATEGIE
*/

int min_max(t_grille grille, char pion, int profondeur)
/* Permet de trouver le meilleur score en foction des coups possibles */
{
    int colonne, meilleurScore, meilleurCoup, score;
    t_grille tmpGrille;
    char F;
    pion = inversePion(pion); // on change le pion (oui, faut changer le joueur qui joue car on joue aussi ceux de l'adversaire)
    F = finMinMax(grille);
    if (profondeur == 0)
    {
        if (F == VIDE){
            return 0; // si on a atteind la prof max on retourne 0 si y'a pas de vainqueur.
        }
    }
    if (F == ADVERSAIRE){
        return (profondeur + 1);
    }
    if (F == JOUEUR){
        return -(profondeur + 1); // si y'a un vainqueur on retourne une valeure qui est loin de 0 si on gagne vite
    }
    meilleurCoup = -1;              // la meillleure colonne a jouer
    meilleurScore = 20;             // ce que ca rapporte (le pire au debut)
    if (pion == ADVERSAIRE){
        meilleurScore = -20;
    }
    for (colonne = 0; colonne < 7; colonne++)
    {
        copieGrille(grille, tmpGrille);   // on utilise la grille temporaire
        if (jouerMinMax(tmpGrille, pion, colonne) == 1) // on joue chaque colonne si possible
        {
            score = min_max(tmpGrille, pion, profondeur - 1);
            if (((score < meilleurScore) && (pion == JOUEUR)) || ((score > meilleurScore) && (pion == ADVERSAIRE))) // on voit si le coup est plus rentable que le meilleur precedent
            {
                meilleurScore = score; // on garde les meilleures
                meilleurCoup = colonne; 
            }
        }
    }
    if (meilleurScore == 20 || meilleurScore == -20){
        meilleurScore = 0; // si y'en a pas eu, on retrourne 0
    }

    return meilleurScore;
}

int choix_colonne(t_grille grille, char pion)
/* Permet de trouver la meilleur colonne a jouer */
{
    int ror[7]; 
    int d, colonne, ligne, meilleurCoup, score;
    t_grille tmpGrille;
    srand(time(NULL)); 
    for (colonne = 0; colonne < 7; colonne++)
    {
        do
        {
            meilleurCoup = 1;
            d = rand() % 7;
            for (ligne = 0; ligne < colonne; ligne++){
                if (ror[ligne] == d){
                    meilleurCoup = 0; // on mélange l'ordre dans lequel on cherche le meilleur coup
                }
            }
                
        } while (meilleurCoup == 0);
        ror[colonne] = d;
    }
    meilleurCoup = -1;
    ligne = 20;
    if (pion == ADVERSAIRE){
        ligne = -20; 
    }
    for (d = 0; d < 7; d++) // meme boucle que dans minmax
    {
        colonne = ror[d];
        copieGrille(grille, tmpGrille);
        if (jouerMinMax(tmpGrille, pion, colonne) == 1)
        {
            score = min_max(tmpGrille, pion, 4); // la profondeur de recherche a 4 (sinon le temps de test est trop long)
            if (((score < ligne) && (pion == JOUEUR)) || ((score > ligne) && (pion == ADVERSAIRE)))
            {
                ligne = score;
                meilleurCoup = colonne;
            }
        }
    }
    if (meilleurCoup == -1) // si pas de coup favoris
    {
        for (colonne = 0; colonne < 7; colonne++)
        {
            copieGrille(grille, tmpGrille);
            if (jouerMinMax(tmpGrille, pion, colonne) == 1){
                meilleurCoup = colonne; // on en cherche un possible, retourne -1 sinon
            }
        }
    }
    return meilleurCoup;
}



bool jouerMinMax(t_grille grille, char pion, int colonne)
/* Permet de jouer un pion et retourne si il est possible de jouer dans cette colonne*/
    {
    int ligne, res;
    res = false;
    if((colonne>0||colonne<6) && (grille[0][colonne] == VIDE)){
        ligne=0;
        while(grille[ligne][colonne]==VIDE && ligne<6){
            ligne++;
        }  
        grille[ligne-1][colonne]=pion;
        res = true;
    } 
    return res;                                                                  
}

char inversePion(char pion)
/* Permet de faire jouer le pion adverse lors des test */
{
    char res;
    if (pion == ADVERSAIRE){
        res = JOUEUR;
    }
    else{
        res = ADVERSAIRE;
    }
    return res;
}

void copieGrille(t_grille grille1, t_grille grille2)
/* Permet de copier la grille1 dans grille2 et servira à placer des pions dans une grille sans modifier la grille principal*/
{
    int ligne, colonne;
    for (ligne = 0; ligne < 6; ligne++){
        for (colonne = 0; colonne < 7; colonne++){
            grille2[ligne][colonne] = grille1[ligne][colonne];  // copie les pions un à un
        } 
    }
        
}

char finMinMax(t_grille grille) 
/* Returne le vainqueur et VIDE si pas de vainqueur et nececite pas de coordonnées en entrée*/
{
    int ligne, colonne, cpt;
    bool trouve = false;
    char resultat;

    for (ligne = 0; ligne < 6; ligne++){
        for (colonne = 0; colonne < 4; colonne++)
        {
            resultat = grille[ligne][colonne];
            trouve = 1;
            if (resultat != VIDE)
            {
                for (cpt = 1; cpt < 4; cpt++)
                {
                    if (grille[ligne][colonne + cpt] != resultat)
                        trouve = 0; // 4 pions horyzonto
                }
                if (trouve == 1)
                    return resultat;
            }
        }
    }
    for (ligne = 0; ligne < 3; ligne++){ //regarde au dessus de 3 ligne du bas pour avoir au moins 4 poins alignés
        for (colonne = 0; colonne < 7; colonne++)
        {
            resultat = grille[ligne][colonne];
            trouve = 1;
            if (resultat != VIDE)
            {
                for (cpt = 1; cpt < 4; cpt++)
                {
                    if (grille[ligne + cpt][colonne] != resultat)
                        trouve = 0; // 4 pions vertico
                }
                if (trouve == 1)
                    return resultat;
            }
        }
    }
    for (ligne = 0; ligne < 3; ligne++){//regarde au dessus de 3 ligne du bas pour avoir au moins 4 poins alignés en diagonal
        for (colonne = 0; colonne < 4; colonne++)
        {
            resultat = grille[ligne][colonne];
            trouve = 1;
            if (resultat != VIDE)
            {
                for (cpt = 1; cpt < 4; cpt++)
                {
                    if (grille[ligne + cpt][colonne + cpt] != resultat)
                        trouve = 0; // 4 pions diagononal
                }
                if (trouve == 1)
                    return resultat;
            }
        }
    }
    for (ligne = 3; ligne < 6; ligne++){
        for (colonne = 0; colonne < 4; colonne++)
        {
            resultat = grille[ligne][colonne];
            trouve = 1;
            if (resultat != VIDE)
            {
                for (cpt = 1; cpt < 4; cpt++)
                {
                    if (grille[ligne - cpt][colonne + cpt] != resultat)
                        trouve = 0; // 4 pions diagononal
                }
                if (trouve == 1)
                    return resultat;
            }
        }
    }
    return VIDE;
}

// La fonction principale reçoit la grille du tour et retourne le coup choisi
// Vous n'avez pas à modifier cette fonction
int main(int argc, char** argv) 
{
    t_grille grille;

    chargerGrille(argv, grille);

    return choix_colonne(grille, JOUEUR);
}

// Charge la grille du tour actuel
// Vous n'avez pas à modifier cette fonction
void chargerGrille(char** argv, t_grille grille) 
{
    for(int i = 0; i < LIGNE; i++)
        for(int j = 0; j < COLONNE; j++)
            grille[i][j] = atoi(argv[i * COLONNE + j + 1]);
}
