/**
* \brief Jeu de puissance 4
*
* \author Tom COHELEACH 
*
* Ce programme permet de jouer au puissance 4. 
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

/**
*
* \def NBLIG
* \brief constante pour le nombre de ligne du tableau.
*
* \def NBCOL
* \brief constante pour le nombre de colonne du tableau.
*
*/

#define NBLIG 6
#define NBCOL 7

/**
*
* \def PION_A;
* \brief constante pour le pion d’un joueur.
*
* \def PION_B;
* \brief constante pour le pion d’un joueur.
*
* \def VIDE;
* \brief constante pour initialiser le tableau avec des valeurs vide et savoir si la case est occupée.
*
* \def INCONNU;
* \brief constante pour savoir si quelqu'un a gagné si égale a INCONNU personne n'a gagné.
*
* \def COLONNE_DEBUT;
* \brief constante avoir la colonne du millieu du tableau.
*
*/

const char PION_A = 'X';
const char PION_B = 'O';
const char VIDE = ' ';
const char INCONNU = ' ';
const int COLONNE_DEBUT = NBCOL/2;


/**
*
* \typedef Grille
*
* \brief type Grille 
*
*
*
*/

typedef char Grille[NBLIG][NBCOL]; 

void regleDuJeu();
void initGrille(Grille g);
void afficher(const Grille g, char pion, int colonne);
bool grillePleine(const Grille g);
void jouer(Grille g, char pion, int *ligne, int *colonne);
int choisirColonne(const Grille g, char, int);
int trouverLigne(const Grille g, int);
bool estVainqueur(const Grille g, int, int);
void finDePartie(char vaiqueur);



int main(){
    char vainqueur;
    int ligne, colonne;
    Grille g;
    regleDuJeu();
    initGrille(g);
    vainqueur = INCONNU;
    afficher(g, PION_A, COLONNE_DEBUT);
    while ((vainqueur == INCONNU) && (grillePleine(g) == 0)){
        jouer(g, PION_A, &ligne, &colonne);
        afficher(g, PION_B, COLONNE_DEBUT);
        if (estVainqueur(g, ligne, colonne) == 1){
            vainqueur = PION_A;
        }
        else if (grillePleine(g) == 0){
            jouer(g, PION_B, &ligne, &colonne);
            afficher(g, PION_A, COLONNE_DEBUT);
            if (estVainqueur(g, ligne, colonne) == 1){
                vainqueur = PION_B;
            }
        }
    }
    finDePartie(vainqueur);
    return EXIT_SUCCESS;
}


void regleDuJeu(){
    /* Fonction qui affiche les regle du jeu si un des joueurs le veut*/
    char reponse[4];
    char tmp;
    printf("Voulez vous voir les regles du jeu ? ");
    scanf("%s%c", reponse, &tmp);
    if(strcmp(reponse, "oui") == 0){
        printf("Le puissance 4 est un jeu qui se joue à 2.\nLe premier à aligner 4 pions de n'importe quelle manière (diagonale, verticale ou horizontale) gagne la partie.\n");
        printf("Pour sortir appuyer sur la touche entrée");
        scanf("%c", &tmp);
    }
}

void initGrille(Grille g){
    /* Fonction qui met la valeur vide pour chaque elements du tableau */
    int i, j;
    for (i=0; i<NBLIG; i++){
        for (j=0; j<NBCOL; j++){
            g[i][j] = VIDE;
        }
    }
}


void afficher(const Grille g, char pion, int colonne){
    /* affiche le plateau de jeu */
    int i, j;
    system("clear");/* Efface l'affichage a l'ecran*/
    i = 0;
    /* Déplacer le pion pour la colonne voulu */
    while ((i < colonne))
    {
        printf("      ");
        i ++;
    }
    printf("   %c  \n", pion);
    i = 0;
    /* Déplacer le cursseur sous le pion pour la colonne voulu */
    while ((i < colonne))
    {
        printf("      ");
        i ++;
    }
    printf("   V  \n");
    /* Entête du plateau */
    for (i=1;i<=NBCOL;i++){
        printf("|  %d  ", i);
    }
    printf("|\n");
    printf("-------------------------------------------\n");
    for (i=1;i<=NBLIG;i++){
        for (j=1;j<=NBCOL;j++){
            printf("|  %c  ", g[i-1][j-1]);/*Car i et j commencent a 1 et fini a 8*/
        }
        printf("|\n");
    }
    printf("-------------------------------------------\n");
}



bool grillePleine(const Grille g){
    /* Verifie si le plateau de jeu est plein */
    int i, j;
    bool resultat;
    i=0;
    resultat = true;
    while ((i < NBLIG) && (resultat == true)){
        for (j=0; j<NBCOL; j++){
            if (g[i][j] == VIDE){
                resultat = false;
            }
        }
        i++;
    }
    return resultat;
}


void jouer(Grille g, char pion, int *ligne, int *colonne){
    /* Permet a un joueur de jouer en appelant les fonction choisirColonne et trouverLigne */
    int col, lig;
    do{
        col = choisirColonne(g, pion, COLONNE_DEBUT);
        lig = trouverLigne(g, col);
        printf("La colonne est remplie\n");/* Sera effacé si la colonne n'est pas remplie */
    }while (lig == -1);/* Si plus de place dans la colonne */
    g[lig][col] = pion;
    *ligne = lig;
    *colonne = col;
}


int choisirColonne(const Grille g, char pion, int colonne){
    /* Permet de choisir une colonne */
    int col;
    char touche, tmp;
    col = colonne;
    printf("gauche > q ; droite > d ; valider > espace :");
    scanf("%c%c", &touche, &tmp);
    while (touche != VIDE){
        if (touche == 'q'){
            if(col == 0){
                printf("Vous ne pouvez pas aller plus a gauche\n");
                printf("droite > d ; valider > espace :");
                scanf("%c%c", &touche, &tmp);
            }
            else{
                col--;
                afficher(g, pion, col);
                printf("gauche > q ; droite > d ; valider > espace :");
                scanf("%c%c", &touche, &tmp);
            }

        }
        else if (touche == 'd'){
            if(col == NBCOL-1){
                printf("Vous etes deja au maximum\n");
                printf("gauche > q ; valider > espace :");
                scanf("%c%c", &touche, &tmp);
            }
            else{
                col++;
                afficher(g, pion, col);
                printf("gauche > q ; droite > d ; valider > espace :");
                scanf("%c%c", &touche, &tmp);
            }  
        }
        else{
            printf("Vous avez du vous tromper de touche reessayer\n");
            printf("gauche > q ; droite > d ; valider > espace :");
            scanf("%c%c", &touche, &tmp);
        }
        
    }
    return col;
}


int trouverLigne(const Grille g , int colonne){
    /* Trouve la ligne la plus basse qui est vide*/
    int i, indice;
    i = 0;
    indice = - 1;
    while ((i < NBLIG) && (g[i][colonne] == VIDE)){
        indice++;
        i++;
    }
    return indice;
}


bool estVainqueur(const Grille g, int ligne, int colonne){
    /* Permet de savoir si un des joueurs a gagné */
    int i, gauche, droite, bas;
    bool trouve;
    i = 1;
    gauche = 1;
    droite = 1;
    trouve = true;
    /* Vérifie la ligne horisontal */
    while ((i < 4) && (trouve == 1))
    {
        if (g[ligne][colonne] == g[ligne][colonne - gauche]){
            gauche++;
            i++;
        }
        else if (g[ligne][colonne] == g[ligne][colonne + droite]){
            droite++;
            i++;
        }
        else{
            trouve = false;
        }
    }
    /* Vérifie la ligne vertical */
    if (trouve == 0){
        trouve = true;
        i = 1;
        bas = 1;
        while ((i < 4) && (trouve == 1))
        {
            if (g[ligne][colonne] == g[ligne + bas][colonne]){
                bas++;
                i++;
            }
            else{
                trouve = false;
            }
        }
    }
    /* Vérifie la ligne diagonal */
    if (trouve == 0){
        trouve = true;
        i = 1;
        gauche = 1;
        droite = 1;
        while ((i < 4) && (trouve == 1))
        {
            if (g[ligne][colonne] == g[ligne + droite][colonne + droite]){
                droite++;
                i++;
            }
            else if (g[ligne][colonne] == g[ligne - gauche][colonne - gauche]){
                gauche++;
                i++;
            }
            else{
                trouve = false;
            }
        }
    }
    /* Vérifie la ligne anti-diagonal */
    if (trouve == 0){
        trouve = true;
        i = 1;
        gauche = 1;
        droite = 1;
        while ((i < 4) && (trouve == 1))
        {
            if (g[ligne][colonne] == g[ligne + droite][colonne - droite]){
                droite++;
                i++;
            }
            else if (g[ligne][colonne] == g[ligne - gauche][colonne + gauche]){
                gauche++;
                i++;
            }
            else{
                trouve = false;
            }
        }
    }

    return trouve;
}



void finDePartie(char vaiqueur){
    /* Affiche le vainquer de la partie */
    if (vaiqueur == PION_A){
        printf("Le joueurA a gagné\n");
    }
    else if (vaiqueur == PION_B){
        printf("Le joueurB a gagné\n");
    }
    else{
        printf("Match nul\n");
    }
}